print("hello, world!")
print(" my name is khang")
print("HUTECH Unniversity")
