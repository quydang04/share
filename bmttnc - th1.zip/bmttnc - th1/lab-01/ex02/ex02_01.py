#nhap ten nguoi dung
ten = input("nhap ten cua ban")
tuoi = input("nhap tuoi cua ban")
print("chao mung,",ten ,"ban", tuoi," tuoi.")
