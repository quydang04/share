let currentCallback = null;

// Storage functions
function saveItems() {
    const listItems = document.querySelector('.list-items');
    const items = [];
    listItems.querySelectorAll('.item').forEach(item => {
        items.push({
            text: item.querySelector('span').textContent,
            checked: item.querySelector('.checkbox').checked
        });
    });
    sessionStorage.setItem('todoItems', JSON.stringify(items));
}

function loadItems() {
    const savedItems = sessionStorage.getItem('todoItems');
    if (savedItems) {
        const items = JSON.parse(savedItems);
        items.forEach(item => {
            createItem(item.text, item.checked);
        });
        updateDeleteButton();
    }
    checkEmptyState();
}

// Helper functions
function checkEmptyState() {
    const listItems = document.querySelector('.list-items');
    const emptyState = document.querySelector('.empty-state');
    if (listItems.children.length === 0) {
        emptyState.style.display = 'flex';
    } else {
        emptyState.style.display = 'none';
    }
}

function createItem(text, checked = false) {
    const listItems = document.querySelector('.list-items');
    const newItem = document.createElement('div');
    newItem.className = 'item';
    newItem.style.opacity = '0';
    newItem.style.transform = 'translateY(20px)';

    const itemContent = document.createElement('div');
    itemContent.className = 'item-content';

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'checkbox';
    checkbox.checked = checked;
    checkbox.onclick = function () {
        updateDeleteButton();
        saveItems();
    };

    const textSpan = document.createElement('span');
    textSpan.textContent = text;

    const buttonGroup = document.createElement('div');
    buttonGroup.className = 'button-group';

    const editButton = document.createElement('button');
    editButton.className = 'edit-btn';
    editButton.innerHTML = '<i class="fas fa-edit"></i> Chỉnh sửa';
    editButton.onclick = function () {
        editItem(textSpan);
    };

    itemContent.appendChild(checkbox);
    itemContent.appendChild(textSpan);
    buttonGroup.appendChild(editButton);
    newItem.appendChild(itemContent);
    newItem.appendChild(buttonGroup);
    listItems.appendChild(newItem);

    requestAnimationFrame(() => {
        newItem.style.opacity = '1';
        newItem.style.transform = 'translateY(0)';
    });

    return newItem;
}

// Modal functions
function showModal(title, value = '', callback) {
    const modal = document.getElementById('inputModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalInput = document.getElementById('modalInput');

    modalTitle.textContent = title;
    modalInput.value = value;
    modal.style.display = "block";
    currentCallback = callback;

    modalInput.focus();
    modalInput.onkeyup = function (event) {
        if (event.key === "Enter") {
            handleConfirm();
        }
    };
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.style.display = "none";
    if (modalId === 'inputModal') {
        currentCallback = null;
        document.getElementById('modalInput').value = '';
    }
}

function handleConfirm() {
    const modalInput = document.getElementById('modalInput');
    const modalContent = modalInput.closest('.modal-content');

    // Remove existing error message if any
    const existingError = modalContent.querySelector('.modal-error');
    if (existingError) {
        existingError.remove();
    }

    if (!modalInput.value.trim()) {
        // Create error message element
        const errorDiv = document.createElement('div');
        errorDiv.className = 'modal-error';
        errorDiv.innerHTML = `
                <i class="fas fa-exclamation-circle"></i>
                <span>Vui lòng nhập nội dung mục!</span>
            `;

        // Insert error after input
        modalInput.insertAdjacentElement('afterend', errorDiv);

        // Trigger animation
        setTimeout(() => errorDiv.classList.add('show'), 10);

        // Shake input
        modalInput.style.borderColor = 'var(--danger-color)';
        modalInput.classList.add('warning-shake');

        // Remove shake class and reset border after animation
        setTimeout(() => {
            modalInput.classList.remove('warning-shake');
        }, 300);

        modalInput.focus();
        return;
    }

    if (currentCallback) {
        currentCallback(modalInput.value);
    }
    closeModal('inputModal');
}

// Item management functions
function addItem() {
    showModal("Thêm mục mới", "", function (text) {
        if (text.trim()) {
            createItem(text);
            saveItems();
            checkEmptyState();
        }
    });
}

function updateDeleteButton() {
    const checkboxes = document.querySelectorAll('.checkbox');
    const deleteBtn = document.getElementById('deleteBtn');
    const hasChecked = Array.from(checkboxes).some(cb => cb.checked);
    deleteBtn.disabled = !hasChecked;

    checkboxes.forEach(checkbox => {
        const item = checkbox.closest('.item');
        if (item) {
            if (checkbox.checked) {
                item.classList.add('selected');
            } else {
                item.classList.remove('selected');
            }
        }
    });
}

// Modify the showConfirmDelete function
function showConfirmDelete() {
    const checkboxes = document.querySelectorAll('.checkbox');
    const selectedCount = Array.from(checkboxes).filter(cb => cb.checked).length;

    if (selectedCount > 0) {
        const modal = document.getElementById('confirmModal');
        const modalText = modal.querySelector('p');
        modalText.textContent = `Bạn có chắc chắn muốn xóa ${selectedCount} mục đã chọn không?`;
        modal.style.display = "block";
    } else {
        // Add warning animation to delete button
        const deleteBtn = document.getElementById('deleteBtn');
        deleteBtn.classList.add('warning-shake');

        // Create and show warning message
        let warningMsg = document.querySelector('.warning-message');
        if (!warningMsg) {
            warningMsg = document.createElement('div');
            warningMsg.className = 'warning-message';
            deleteBtn.parentNode.appendChild(warningMsg);
        }
        warningMsg.textContent = 'Vui lòng chọn ít nhất một mục để xóa!';
        warningMsg.style.display = 'block';

        // Remove warning after animation
        setTimeout(() => {
            deleteBtn.classList.remove('warning-shake');
            warningMsg.style.display = 'none';
        }, 2000);
    }
}

function confirmDelete() {
    const items = document.querySelectorAll('.item');
    items.forEach(item => {
        if (item.querySelector('.checkbox').checked) {
            item.style.opacity = '0';
            item.style.transform = 'translateX(20px)';
            setTimeout(() => {
                item.remove();
                saveItems();
                checkEmptyState();
            }, 300);
        }
    });
    updateDeleteButton();
    closeModal('confirmModal');
}

function editItem(textSpan) {
    showModal("Chỉnh sửa mục", textSpan.textContent, function (newText) {
        if (newText.trim()) {
            textSpan.textContent = newText;
            textSpan.style.backgroundColor = '#fff9c4';
            setTimeout(() => {
                textSpan.style.backgroundColor = 'transparent';
            }, 1000);
            saveItems();
        }
    });
}

// Event listeners
window.onclick = function (event) {
    const modals = document.getElementsByClassName('modal');
    Array.from(modals).forEach(modal => {
        if (event.target === modal) {
            closeModal(modal.id);
        }
    });
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadItems();
    checkEmptyState();
});
// Add this function
function showWelcomeModal() {
    const welcomeModal = document.getElementById('welcomeModal');
    welcomeModal.style.display = 'block';

    setTimeout(() => {
        welcomeModal.style.opacity = '0';
        welcomeModal.style.transition = 'opacity 0.5s ease';
        setTimeout(() => {
            welcomeModal.style.display = 'none';
            welcomeModal.style.opacity = '1';
        }, 500);
    }, 10000);
}

// Modify the initialization
document.addEventListener('DOMContentLoaded', () => {
    loadItems();
    checkEmptyState();
    showWelcomeModal();
});