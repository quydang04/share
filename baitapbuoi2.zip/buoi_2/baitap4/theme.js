// Theme handling
function initTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    // Add transition animation to main content
    const mainContent = document.getElementById('main-content');
    mainContent.style.transition = 'all 0.3s ease';
    
    // Update theme
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    // Update icon with animation
    const icon = document.querySelector('.theme-toggle i');
    icon.style.transition = 'transform 0.3s ease';
    icon.style.transform = 'rotate(180deg)';
    
    setTimeout(() => {
        icon.classList.remove(newTheme === 'dark' ? 'fa-moon' : 'fa-sun');
        icon.classList.add(newTheme === 'dark' ? 'fa-sun' : 'fa-moon');
        icon.style.transform = 'rotate(0deg)';
    }, 150);
}

function updateThemeIcon(theme) {
    const icon = document.querySelector('.theme-toggle i');
    icon.classList.remove(theme === 'dark' ? 'fa-moon' : 'fa-sun');
    icon.classList.add(theme === 'dark' ? 'fa-sun' : 'fa-moon');
}

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    setupEventListeners();
});

function setupEventListeners() {
    // Add event listeners for modals
    window.onclick = (event) => {
        if (event.target.classList.contains('modal')) {
            closeModal(event.target.id);
        }
    };

    // Add keyboard event listeners
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            const modals = document.getElementsByClassName('modal');
            Array.from(modals).forEach(modal => {
                if (modal.style.display === 'block') {
                    closeModal(modal.id);
                }
            });
        }
    });
}