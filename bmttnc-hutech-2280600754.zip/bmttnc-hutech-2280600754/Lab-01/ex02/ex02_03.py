#Nhap so tu nguoi dung
so = int(input("Nhap so: "))
#Kiem tra so nhap vao la so chan hay le
if so % 2 == 0:
    print(so, "la so chan")
else:
    print(so, "la so le")