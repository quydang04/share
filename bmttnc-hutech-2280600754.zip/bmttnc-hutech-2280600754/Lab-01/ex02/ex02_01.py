#Nhap ten tuoi nguoi dung
ten = input("Nhap ten cua ban: ")
tuoi = input("Nhap tuoi cua ban: ")
#In thong diep chao mung voi thong tin vua nhap
print("Chao mung", ten, "Ban", tuoi, "tuoi")