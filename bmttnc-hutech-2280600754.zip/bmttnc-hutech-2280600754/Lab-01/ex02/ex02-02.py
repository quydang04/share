#Nhap ban kinh tu nguoi dung 
ban_kinh = float(input("Nhap ban kinh hinh tron: "))
#tinh dien tich hinh tron
dien_tich = 3.14 * ban_kinh * ban_kinh
#in ket qua
print("Dien tich hinh tron co ban kinh", ban_kinh, "la", dien_tich)