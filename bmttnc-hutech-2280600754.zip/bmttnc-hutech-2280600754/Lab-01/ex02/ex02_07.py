#Nhap cac dong tu nguoi dung
print("Nhap cac dong tu van ban (nhap 'Done' de ket thuc):")
lines = []
while True:
    line = input()
    if line == 'Done':
        break
    lines.append(line)
#Chuyen cac dong thanh chu in hoa vaf in ra man hinh
print("\nCac dong da nhap sau khi chuyen thanh chu in hoa:")
for line in lines:
    print(line.upper())