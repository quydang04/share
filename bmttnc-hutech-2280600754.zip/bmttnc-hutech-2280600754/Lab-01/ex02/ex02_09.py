def kiem_tra_so_nguyen_to(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True
#Kiem tra so nguyen to va in ket qua
number = int(input("Nhap so: "))
if kiem_tra_so_nguyen_to(number):
    print(number, "la so nguyen to")
else:
    print(number, "khong phai la so nguyen to")